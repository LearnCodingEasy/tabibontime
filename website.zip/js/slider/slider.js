"use strict";
//# sourceMappingURL=slider.js.map
